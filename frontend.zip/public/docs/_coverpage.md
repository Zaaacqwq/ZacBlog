<!-- _coverpage.md -->

![logo](_media/icon.svg)

# Blog <small>1.0</small>

> 一个简单的博客网站。

- 简单、轻便 (感谢 ruoyi 平台)
