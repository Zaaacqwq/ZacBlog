import bg1 from '../../../assets/images/file.png'
export default{
	bg1,
}