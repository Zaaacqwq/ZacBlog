<template>
    <div class="footer">
      <span style="color: #FFFFFF;line-height:40px;font-size: 12px;">Copyright © 2021-2025 Ning All Rights Reserved.</span>
    </div>
</template>

<script>
  export default {
    name: 'cmsFooter',
  }
</script>

<style scoped>
  .footer {
    text-align: center;
  }
</style>
