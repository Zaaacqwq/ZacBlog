// 背景图片随机生成
import bg1 from '../../assets/images/wallhaven-dgojvj.webp'
import bg2 from '../../assets/images/wallhaven-j5y525.webp'
import bg3 from '../../assets/images/wallhaven-k9p8l6.webp'
export default[
	bg1,
	bg2,
	bg3,
]
