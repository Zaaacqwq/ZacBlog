package com.zaaac.common.core.domain.model;

/**
 * 用户注册对象
 * 
 * @author zaaac
 */
public class RegisterBody extends LoginBody
{

}
